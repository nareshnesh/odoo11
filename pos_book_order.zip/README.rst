POS Booking Order
=================
* Book orders from pos.

Author
=======
* Cybrosys Techno Solutions


Credits
=========
* Developer:
  Varsha Vivek odoo@cybrosys.com

Contacts
========
* Cybrosys Technologies <https://www.cybrosys.com>
