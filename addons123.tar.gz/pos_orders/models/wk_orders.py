# -*- coding: utf-8 -*-
#################################################################################
#
#   Copyright (c) 2016-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#   See LICENSE file for full copyright and licensing details.
#   License URL : <https://store.webkul.com/license.html/>
# 
#################################################################################
from odoo import api, fields, models
from datetime import datetime
from odoo.exceptions import Warning,ValidationError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT

import pytz

class PosOrder(models.Model):
    _inherit = 'pos.order'
    
    @api.model
    def create_from_ui(self,orders):
        order_ids = super(PosOrder,self).create_from_ui(orders)
        order_objs = self.env['pos.order']
        if type(order_ids) == dict:
            order_objs = self.env['pos.order'].browse(order_ids.get('order_ids'))
        else:
            for order_id in order_ids:
                if order_id:
                    order_objs += self.env['pos.order'].browse(order_id)
        result = {}
        order_list = []
        order_line_list = []
        statement_list = []
        for order_obj in order_objs:
            vals = {}
            vals['lines'] = []
            if hasattr(order_objs[0], 'return_status'):
                if not order_obj.read():
                    continue
                if not order_obj.is_return_order:
                    vals['return_status'] = order_obj.return_status
                    vals['existing'] = False
                    vals['id'] = order_obj.id
                else:
                    order_obj.return_order_id.return_status = order_obj.return_status
                    vals['existing'] = True
                    vals['id'] = order_obj.id
                    vals['original_order_id'] = order_obj.return_order_id.id
                    vals['return_status'] = order_obj.return_order_id.return_status
                    for line in order_obj.lines:
                        line_vals = {}
                        if line.original_line_id:
                            line_vals['id'] = line.original_line_id.id
                            line_vals['line_qty_returned'] = line.original_line_id.line_qty_returned
                            line_vals['existing'] = True
                        order_line_list.append(line_vals)
            vals['statement_ids'] = order_obj.statement_ids.ids
            vals['name'] = order_obj.name
            vals['amount_total'] = order_obj.amount_total
            vals['pos_reference'] = order_obj.pos_reference
            vals['date_order'] = order_obj.date_order
            if order_obj.invoice_id:
                vals['invoice_id'] = order_obj.invoice_id.id
            else:
                vals['invoice_id'] = False
            if order_obj.partner_id:
                vals['partner_id'] = [order_obj.partner_id.id, order_obj.partner_id.name]
            else:
                vals['partner_id'] = False
            if (not hasattr(order_objs[0], 'return_status') or (hasattr(order_objs[0], 'return_status') and not order_obj.is_return_order)):
                vals['id'] = order_obj.id
                for line in order_obj.lines:
                    vals['lines'].append(line.id)
                    line_vals = {}
                    # LINE DATAA
                    line_vals['create_date'] = line.create_date
                    line_vals['discount'] = line.discount
                    line_vals['display_name'] = line.display_name
                    line_vals['id'] = line.id
                    line_vals['order_id'] = [line.order_id.id, line.order_id.name]
                    line_vals['price_subtotal'] = line.price_subtotal
                    line_vals['price_subtotal_incl'] = line.price_subtotal_incl
                    line_vals['price_unit'] = line.price_unit
                    line_vals['product_id'] = [line.product_id.id, line.product_id.name]
                    line_vals['qty'] = line.qty
                    line_vals['write_date'] = line.write_date
                    if hasattr(line, 'line_qty_returned'):
                        line_vals['line_qty_returned'] = line.line_qty_returned
                    # LINE DATAA
                    order_line_list.append(line_vals)
                for statement_id in order_obj.statement_ids:
                    statement_vals = {}
                    # STATEMENT DATAA
                    statement_vals['amount'] = statement_id.amount
                    statement_vals['id'] = statement_id.id
                    if statement_id.journal_id:
                        currency = statement_id.journal_id.currency_id or statement_id.journal_id.company_id.currency_id
                        statement_vals['journal_id'] = [statement_id.journal_id.id, statement_id.journal_id.name + " (" +currency.name+")"]
                    else:
                        statement_vals['journal_id'] = False
                    statement_list.append(statement_vals)
            order_list.append(vals)
        result['orders'] = order_list
        result['orderlines'] = order_line_list
        result['statements'] = statement_list
        result['order_ids'] = order_ids
        return result

    @api.model
    def func_fetch_db(self):
        user_tz = self.env.user.tz or pytz.utc
        local = pytz.timezone(user_tz)
        order_objs = self.env['pos.order']
        order_ids = self.env['pos.order'].search([('state', '=', 'paid'), ('is_return_order', '=', False)],
                                                 order="id desc")
        order_list = []
        for order in order_ids:
            vals = {}
            # display_date_result = datetime.strftime(
            #     pytz.utc.localize(datetime.strptime(order.date_order, DEFAULT_SERVER_DATETIME_FORMAT)).astimezone(
            #         local), "%d/%m/%Y %H:%M")
            vals['lines'] = []
            vals['id'] = order.id
            vals['date_order'] = order.date_order
            vals['amount_total'] = round(order.amount_total,2)
            vals['name']= order.name
            vals['pos_reference'] = order.pos_reference
            vals['statement_ids'] = []
            if order.invoice_id:
                vals['invoice_id'] = order.invoice_id.id
            else:
                vals['invoice_id'] = False
            if order.partner_id:
                print(order.partner_id)
                vals['partner_id']=[order.partner_id.id,order.partner_id.name]
            else:
                vals['partner_id'] = False
            vals['is_return_order'] = order.is_return_order
            vals['return_status'] = order.return_status
            if order.return_order_id:
                vals['return_order_id'] = order.return_order_id.id
            else:
                vals['return_order_id'] = False

            for line in order.lines:
                vals['lines'].append(line.id)

            for statement_id in order.statement_ids:
                # STATEMENT DATAA
                vals['statement_ids'].append(statement_id.id)

            order_list.append(vals)

        return order_list

    @api.model
    def func_fetch_order_line_db(self,id):

        order_objs = self.env['pos.order.line']
        orderline = self.env['pos.order.line'].search([('id', '=', id)])

        order_line = {}
        order_line['discount'] = orderline.discount
        order_line['id'] = orderline.id
        order_line['line_qty_returned'] = orderline.line_qty_returned
        order_line['order_id'] = [orderline.order_id.id, orderline.order_id.name]
        order_line['price_subtotal'] = orderline.price_subtotal
        order_line['price_subtotal_incl'] = orderline.price_subtotal_incl
        order_line['price_unit'] = orderline.price_unit
        order_line['product_id'] = [orderline.product_id.id,orderline.product_id.name]
        order_line['qty'] = orderline.qty

        return order_line

    @api.model
    def func_statement_id(self, id):

        statement_id = self.env['account.bank.statement.line'].search([('id', '=', id)])
        statement_vals = {}
        # STATEMENT DATAA
        statement_vals['amount'] = statement_id.amount
        statement_vals['id'] = statement_id.id
        if statement_id.journal_id:
            currency = statement_id.journal_id.currency_id or statement_id.journal_id.company_id.currency_id
            statement_vals['journal_id'] = [statement_id.journal_id.id,
                                            statement_id.journal_id.name + " (" + currency.name + ")"]
        else:
            statement_vals['journal_id'] = False
        return statement_vals

class PosConfig(models.Model):
    _inherit = 'pos.config'

    order_loading_options = fields.Selection([("current_session","Load Orders Of Current Session"), ("all_orders","Load All Past Orders"), ("n_days","Load Orders Of Last 'n' Days")], default='current_session', string="Loading Options")
    number_of_days = fields.Integer(string='Number Of Past Days',default=10)

    @api.constrains('number_of_days')
    def number_of_days_validation(self):
        if self.order_loading_options == 'n_days':
            if not self.number_of_days or self.number_of_days < 0:
                raise ValidationError("Please provide a valid value for the field 'Number Of Past Days'!!!")



class StatementLine(models.Model):
    _inherit = 'account.bank.statement.line'

    @api.model
    def func_statement_id(self,id):
        statement_id = self.env['account.bank.statement.line'].search([('id', '=', id)])

        for statement_id in order_obj.statement_ids:
            statement_vals = {}
            # STATEMENT DATAA
            statement_vals['amount'] = statement_id.amount
            statement_vals['id'] = statement_id.id
            if statement_id.journal_id:
                currency = statement_id.journal_id.currency_id or statement_id.journal_id.company_id.currency_id
                statement_vals['journal_id'] = [statement_id.journal_id.id,
                                                statement_id.journal_id.name + " (" + currency.name + ")"]
            else:
                statement_vals['journal_id'] = False
            statement_list.append(statement_vals)
        statement = { 'amount' : statement_id.amount,
                      'id' : statement_id.id,
                      'journal_id':  [statement_id.journal_id.id, statement_id.journal_id.name + " (" +currency.name+")"]
            }
        return statement

